package com.eecs481simplegame;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Point;
import android.util.DisplayMetrics;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Random;
import android.view.*;
import android.view.View.OnClickListener;
import android.widget.*;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.view.View.INVISIBLE;

public class MainActivity extends Activity {

	public static final int GAME_LENGTH = 10;
	public enum State {START, PLAYING, PLAYAGAIN};
	
	//DisplayMetrics metrics = getResources().getDisplayMetrics();
	int width = 200;
	int height = 200;
	
	
	private class Game
	{
		int points;
		State gameState;
		int buttonsLeft;
		public Game(int p, State s){points = p; gameState = s;}
	
	}
	Game game = new Game(0,State.START);
	Timer t = new Timer("GameTimer");
	Random rng = new Random(System.currentTimeMillis());
	
	public class draw extends TimerTask
	{
		public void run()
		{
			MainActivity.this.runOnUiThread(new Runnable() {
			    public void run() {
			        Button button = (Button)findViewById(R.id.hitButton);
					button.setX(rng.nextInt(width-50));
					button.setY(rng.nextInt(height-50));
					
			    	button.setVisibility(VISIBLE);
			    }
			});
			
	    	
	    	t.schedule(new delay(), rng.nextInt(500)+250);
			
		}
	
	}
	
	public class delay extends TimerTask
	{
		public void run()
		{
			//This runs when player doesn't hit the button
			MainActivity.this.runOnUiThread(new Runnable() {
			    public void run() {
			        
			    	Button button = (Button)findViewById(R.id.hitButton);
					button.setVisibility(INVISIBLE);
					game.points--;
					game.buttonsLeft--;
					if (game.buttonsLeft == 0)
					{
						Button b = (Button)findViewById(R.id.playButton);
				    	b.setVisibility(VISIBLE);
				    	
				    	
				    	TextView tv = (TextView)findViewById(R.id.scoreDisplay);
				    	tv.setVisibility(VISIBLE);
				    	tv.setText("Your Score: "+game.points);
					}
					else t.schedule(new draw(), rng.nextInt(1000));
			    }
			});
			
		}
	};
	
	private OnClickListener buttonListener = new OnClickListener() {
	    public void onClick(View v) {
	      // starts the game
	    	Button button = (Button)findViewById(R.id.playButton);
	    	button.setVisibility(GONE);
	    	
	    	Button b = (Button)findViewById(R.id.hitButton);
	    	b.setVisibility(VISIBLE);
	    	
	    	TextView tv = (TextView)findViewById(R.id.scoreDisplay);
	    	tv.setVisibility(INVISIBLE);
	    	game.buttonsLeft = GAME_LENGTH;
	    	game.points = 0;
	    	
	    	t.schedule(new draw(), rng.nextInt(1000));
	    }		
	};
	
	private OnClickListener hitListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			//User hits the button
			t.cancel();
			t = new Timer();
			Button button = (Button)findViewById(R.id.hitButton);
	    	button.setVisibility(INVISIBLE);
			game.points+=3;
			t.schedule(new draw(), rng.nextInt(1000));			
			
		}
	
	};
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Button playButton = (Button)findViewById(R.id.playButton);
    	playButton.setOnClickListener(buttonListener);
    	
    	Button hitButton = (Button)findViewById(R.id.hitButton);
    	hitButton.setOnClickListener(hitListener);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
