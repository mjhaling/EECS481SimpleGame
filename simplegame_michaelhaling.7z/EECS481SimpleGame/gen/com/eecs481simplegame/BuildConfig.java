/** Automatically generated file. DO NOT MODIFY */
package com.eecs481simplegame;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}